function [ShiftVector , RotationMatrix]= IO( problem)
%IO ��ȡ���е�rotation matrix ��Shift vector
%   �˴���ʾ��ϸ˵��
ShiftVector  = {};
RotationMatrix = {};


for i = 1:50
    switch problem
        case 2
            ShiftVectorName = ['SVector/S2/S2_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M2/M2_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
        case 3
            ShiftVectorName = ['SVector/S3/S3_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M3/M3_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
        case 1
            ShiftVectorName = ['SVector/S1/S1_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M1/M1_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
        case 4
            ShiftVectorName = ['SVector/S4/S4_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M4/M4_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
        case 5
            ShiftVectorName = ['SVector/S5/S5_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M5/M5_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
        case 6
            ShiftVectorName = ['SVector/S6/S6_' , num2str(i)];
            ShiftVectorName = [ShiftVectorName , '.txt'];
            RotationMatrixName = ['M/M6/M6_' , num2str(i)];
            RotationMatrixName = [RotationMatrixName , '.txt'];
            ShiftVector{i} = textread(ShiftVectorName);
            RotationMatrix{i} = textread(RotationMatrixName);
    end
end
end

