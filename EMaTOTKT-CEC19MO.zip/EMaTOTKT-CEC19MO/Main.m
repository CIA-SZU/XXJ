clear all
beep off
warning off
gen = 1000;
IGD = {};
rmp=0.3; % Random mating probability
muc = 20 ; % Distribution Index of SBX crossover operator
mum = 20; % Distribution Index of Polynomial Mutation operator
for run=1:20 %running times
    for index = 1:6 %problem index
        [IGD{run,index} , population{run,index}] =  EMaTOTKT(gen,muc,mum,index);
    end
end

save('IGD' , 'IGD');