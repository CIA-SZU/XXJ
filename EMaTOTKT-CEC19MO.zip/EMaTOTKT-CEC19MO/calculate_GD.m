function [GD]=calculate_GD( data , benchmark_Num )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%���ݲ�ͬ���������IGD��ֵ
%   �˴���ʾ��ϸ˵��
% IGD = 0;
% Distance = min(pdist2(PF,data),[],2);
% sum1 = sum(Distance);
% sum1=  sqrt(sum1);
% IGD = sum1 / length(PF);
load concave.pf
load convex.pf
load circle.pf
switch benchmark_Num
    case {1,4,6}
        
     Distance = min(pdist2(data,circle),[],2);
    GD    = norm(Distance) / length(Distance);
    

    case {2,3}
     Distance = min(pdist2(data,concave),[],2);
    GD    = norm(Distance) / length(Distance);
    otherwise
     Distance = min(pdist2(data,convex),[],2);
    GD    = norm(Distance) / length(Distance);
end

