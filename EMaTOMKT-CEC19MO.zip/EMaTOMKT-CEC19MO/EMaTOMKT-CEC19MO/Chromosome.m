classdef Chromosome
    
    properties
        rnvec;
        obj
        convio;
        skill_factor;
        front;%���ڵڼ���
        CD;
        rank;%��ʾ�ǵڼ�������
        dominationcount=0;
        dominatedset=[];
        dominatedsetlength=0;
        improvedFromOtherTask = 0;
        survivedFromOperator;
        cluster_num;
    end
    
    methods
        
        function object=initialize(object,dim)
            object.rnvec=(rand(1,dim));
        end
        
        function [child1 , child2]=evaluate(child1, child2 , benchMark_num)
            
            %child1 , child2��Ϊ���������Ⱥ
            switch benchMark_num
                case 1
                    [child1 , child2 ] = CPLX1(child1, child2 );        %��������
                    
                case 2
                    [child1 , child2 ] = CPLX2(child1, child2 );        %��������
                    
                case 3
                    [child1 , child2 ] = CPLX3(child1, child2 );        %��������
                    
                case 4
                    [child1 , child2 ] = CPLX4(child1, child2 );        %��������
                    
                case 5
                    [child1 , child2 ] = CPLX5(child1, child2 );        %��������
                    
                case 6
                    [child1 , child2 ] = CPLX6(child1, child2 );        %��������
                case 7
                    [child1 , child2 ] = CPLX7(child1, child2 );        %��������
                case 8
                    [child1 , child2 ] = CPLX8(child1, child2 );        %��������
                case 9
                    [child1 , child2 ] = CPLX9(child1, child2 );        %��������
                case 10
                    [child1 , child2 ] = CPLX10(child1, child2 );        %��������
                    
                    
            end
        end
        
        function population=reset(population,pop)
            for i=1:pop
                population(i).dominationcount=0;
                population(i).dominatedset=[];
                population(i).dominatedsetlength=0;
            end
        end
    end
    
end

