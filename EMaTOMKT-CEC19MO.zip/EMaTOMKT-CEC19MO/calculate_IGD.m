function [IGD]=calculate_IGD( data , benchmark_Num )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%���ݲ�ͬ���������IGD��ֵ
%   �˴���ʾ��ϸ˵��
load concave.pf
load convex.pf
load circle.pf
switch benchmark_Num
    case {1,4,6}
        Distance = min(pdist2(circle,data),[],2);
        Distance = Distance .^ 2;
        sum1 = sum(Distance);
        sum1 = sqrt(sum1);
        IGD = sum1 / length(circle);
    case {2,3}
        Distance = min(pdist2(concave,data),[],2);
         Distance = Distance .^ 2;
        sum1 = sum(Distance);
        sum1 = sqrt(sum1);
        IGD = sum1 / length(concave);
    otherwise
        Distance = min(pdist2(convex,data),[],2);
         Distance = Distance .^ 2;
        sum1 = sum(Distance);
        sum1 = sqrt(sum1);
        IGD = sum1 / length(convex);
end

