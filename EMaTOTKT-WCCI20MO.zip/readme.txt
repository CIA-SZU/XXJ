This program mainly implements the EMaTO-TKT which was described in our paper:

An Evolutionary Many-task Optimization Algorithm with Three-level Knowledge Transfer Mechanism

Different file names refer to the corresponding test suite.For any problem concerning the code, please feel free to contact XuXiuju (email: 377611694@qq.com).