This program mainly implements the EMaTO-MKT which was described in our paper:

Evolutionary Many-task Optimization Based on Multi-source Knowledge Transfer

Different file names refer to the corresponding test suite.For any problem concerning the code, please feel free to contact XuXiuju (email: 377611694@qq.com).