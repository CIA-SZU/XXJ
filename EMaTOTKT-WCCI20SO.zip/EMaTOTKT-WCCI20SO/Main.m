clear
warning off
pop=5000; % population size
gen=1000; % generation
rmp=0.3; % random mating probability
for run=1 : 20 %running times
    for index = 1:10%problem index
        Tasks = benchmark(index);
        [population{run,index},  data_EMaTOTKT{run,index}] = EMaTOTKT(Tasks,pop,gen);
    end
end
save('data_EMaTOTKT','data_EMaTOTKT');