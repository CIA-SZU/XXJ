classdef Chromosome    
    properties
        rnvec; % (genotype)--> decode to find design variables --> (phenotype) 
        factorial_costs;
        factorial_ranks;
        scalar_fitness;
        skill_factor;
        improvedFromOtherTask;
        cluster_num;
    end    
    methods        
        function object = initialize(object,D)            
            object.rnvec = rand(1,D);            
        end
        
        function [object] = evaluate(object,Tasks)     
                    [object.factorial_costs,~]=fnceval(Tasks(object.skill_factor),object.rnvec);
        end
        
        % SBX
        function object=crossover(object,p1,p2,cf)
            object.rnvec=0.5*((1+cf).*p1.rnvec + (1-cf).*p2.rnvec);
            object.rnvec(object.rnvec>1)=1;
            object.rnvec(object.rnvec<0)=0;
        end
        
        % polynomial mutation
        function object=mutate(object,p,dim,mum)
            rnvec_temp=p.rnvec;
            for i=1:dim
                if rand(1)<1/dim
                    u=rand(1);
                    if u <= 0.5
                        del=(2*u)^(1/(1+mum)) - 1;
                        rnvec_temp(i)=p.rnvec(i) + del*(p.rnvec(i));
                    else
                        del= 1 - (2*(1-u))^(1/(1+mum));
                        rnvec_temp(i)=p.rnvec(i) + del*(1-p.rnvec(i));
                    end
                end
            end  
            object.rnvec = rnvec_temp;          
        end  
        
        function object=crossoverMaTGA(object,p1,p2)
            indorder = randperm(length(p1.rnvec));
            k = indorder(1);
            for i = 1 : length(p1.rnvec)
                r = 0.1 + 0.8*rand(1);
                if rand(1) < r || i == k
                    object.rnvec(i) = p2.rnvec(i);
                else
                    object.rnvec(i) = p1.rnvec(i);
                end
            end
            object.rnvec(object.rnvec>1)=1;
            object.rnvec(object.rnvec<0)=0;
        end
        
    end
end