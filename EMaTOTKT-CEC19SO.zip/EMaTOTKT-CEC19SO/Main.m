warning off
clear
pop=5000; % population size 
gen=1000; % generation count
rmp=0.3; % random mating probability
for  run =1:20
    for index = 1 : 6
        Tasks = benchmark(index);
        [population{run,index},data_EMaTOTKT{run,index}] = EMaTOTKT(Tasks,pop,gen);
    end
end
save('data_EMaTOTKT.mat','data_EMaTOTKT');
